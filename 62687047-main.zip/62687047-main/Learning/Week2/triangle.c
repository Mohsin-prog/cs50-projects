#include <cs50.h>
#include <stdio.h>

bool valid_triangle(float x, float y, float z);

int main (void)
{
    int x = get_int("Enter your 1 real number: ");
    int y = get_int("Enter your 2 real number: ");
    int z = get_int("Enter your 3 real number: ");

   // printf("Your 1 real number is %i\nYour 2 real number is %i\nYour 3 real number is %i\n", x, y, z);

    int t = valid_triangle(x, y, z);
    printf("Triangle %i\n", t);
}

bool valid_triangle(float x, float y, float z)
{
    // check for all positive sides
    if (x <= 0 || y <= 0 || z <= 0)
    {
        return false;
    }

    // check that sum of any two sides greater than third
    if ((x = y <= z) || (x + z <= y) || (y + z <= x))
    {
        return false;
    }

    // if we passed both tests, we're good!
    return true;
}
