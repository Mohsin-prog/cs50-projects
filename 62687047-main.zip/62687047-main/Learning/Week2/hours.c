#include <stdio.h>
#include <cs50.h>

int main (void)
{
    int hour[5] = {7, 5, 3, 8, 4};
    for (int i = 0; i < 5; i++)
    {
        printf("%i\n", hour[i]);
    }
}