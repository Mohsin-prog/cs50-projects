#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

bool check_phrase(string phrase);

int main(void)
{
    string phrase = get_string("What's the secret phrase? ");

    bool correct = check_phrase(phrase);

    if (correct == true)
    {
        printf("come on in!\n");
    }
    else
    {
        printf("Wrong Phrase\n");
        return 0;
    }
}

bool check_phrase(string phrase)
{
    string password = "Please";

    if (strcmp(phrase, password) == 0)
    {
        return true;
    }
    return false;
}
