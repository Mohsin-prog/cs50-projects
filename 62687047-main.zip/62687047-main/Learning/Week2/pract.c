#include <cs50.h>
#include <stdio.h>

int main(void)
{
    //Using -l(library name) to run the code
    //Using clang -o pract pract.c to compile or run the program
    string name = get_string("Enter your name ");
    printf("Hello, %s\n", name);
}