#include <stdio.h>
#include <cs50.h>

int main (void)
{
    // Get the length from the User
    int length;
    do
    {
        length= get_long("length: ");
    }
    while (length < 1);

    //Declare our array
    long twice[length];

    //Set the first Value
    twice[0] = 1;
    printf("%li\n", twice[0]);

    for (long i = 1; i < length; i++)
    {
        // Make the current element twice the previous
        twice[i] = 2 * twice[i - 1];

        // Print the crrent Element
        printf("%li\n", twice[i]);
    }

}