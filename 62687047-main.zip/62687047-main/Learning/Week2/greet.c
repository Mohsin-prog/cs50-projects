#include <cs50.h>
#include <stdio.h>

int main (int argc, string argv[])
{
    //printf("hello, %s %s\n", argv[1], argv[2]);


    /*
    if(argc == 2)
    {
        printf("hello, %s\n", argv[1]);
    }
    else
    {
        printf("hello World\n");
    }
    */

   if (argc != 2)
   {
    printf("Missing command-line argument\n");
    return 1;
   }
   else
   {
    printf("Hello, %s\n", argv[1]);LEa
   }
}