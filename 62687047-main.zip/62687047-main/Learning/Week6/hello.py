from cs50 import get_string

answer = get_string("What's your name? ")
print(f"hello, {answer}")
