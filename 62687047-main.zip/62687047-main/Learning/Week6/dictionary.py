words = set()

def check(word):
    return word.lower() in words

def load(dictionary):
    try:
        with open(dictionary, "r") as file:
            for line in file:
                word = line.rstrip()
                words.add(word)
        return True
    except FileNotFoundError:
        return False

def size():
    return len(words)

def upload():
    # Add your implementation for uploadingwords here
    return True  # Placeholder, modify as needed
