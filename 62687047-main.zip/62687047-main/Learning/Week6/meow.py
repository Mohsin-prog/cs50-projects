def main():
    meow(3)

def meow(n):
    for i in range(n):
        print("meow")

main()
