before = input("Before: ")
after = before.lower()
print(f"After: {after}")

