""""from cs50 import get_int

x = get_int("x: ")
y = get_int("y: ")"""

x = int(input("x: "))
y = int(input("y: "))


z = x / y
print(f"{z:.50f}")
