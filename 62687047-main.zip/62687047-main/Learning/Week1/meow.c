#include <stdio.h>

int main(void)
{
    //While loop
    /*Using Substraction Method
    int i = 3;
    while( i > 0)
    {
        printf("Meow\n");
        i--;
    }
    */

   /*Using Addition Method
   int i = 1;
   while(i <= 3)
   {
    printf("Meow\n");
    i++;
   }
   */
   int i = 0;
   while(i < 3)
   {
    printf("Meow\n");
    i++;
   }

   // for loop
   for(i = 0; i < 3; i++)
   {
    printf("Meow\n");
   }
}