#include <stdio.h>
#include <cs50.h>

int main(void)
{
    string name = get_string("What is your Name? ");
    int age = get_int("What's your age? ");
    long number = get_long("What's your Phone Number? " );

    printf("Data add Confirm \n");
    printf("Name is %s. Age is %i. Phone Number is %li \n ", name, age, number);



}