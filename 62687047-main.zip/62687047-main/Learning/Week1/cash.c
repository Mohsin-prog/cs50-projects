#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int cents;
    do
    {
        cents = get_int("Cash owed: ");
    }
    while (cents <= 0);



    printf("%i\n", cents);

} 