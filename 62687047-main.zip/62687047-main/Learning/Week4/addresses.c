#include <stdio.h>
//#include <cs50.h>


int main(void)
{
   // int n = 50;
   // int *p = &n;
   // printf("%i\n", *p);


    //string s = "Hi!";
   //printf("%s\n", s);


    //char * = string
   /* char *s = "Hi!";
    printf("%p\n", s);
    printf("%p\n", &s[0]);
    printf("%p\n", &s[1]);
    printf("%p\n", &s[2]);
    printf("%p\n", &s[3]);
    */


   //Pointer Arithmetic

   char *s = "Hi!";
   printf("%c\n", *s);
   printf("%c\n", *(s + 1));
   printf("%c\n", *(s + 2));
   
}