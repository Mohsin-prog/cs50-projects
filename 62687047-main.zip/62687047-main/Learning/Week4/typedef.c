#include <stdio.h>

int main void{
struct car
(
    int year;
    char model[18];
    char plate[7];
    int odometer;
    double engine_size;
);
}

typedef struct car car_t;