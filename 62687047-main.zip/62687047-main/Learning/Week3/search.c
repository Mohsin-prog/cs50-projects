#include <stdio.h>
#include <cs50.h>
#include <string.h>
//Linear Search Implemntation
int main(void)
{
    /*
    // Statically define an aray using integer
    int number[] = {20, 500, 10, 5, 100, 1, 50};

    int n = get_int("Number: ");
    for (int i = 0; i < 7; i++)
    {
        if(number[i] == n)
        {
            printf("Found!\n");
            return 0;
        }
    }
    printf("Nout Found!\n");

    return 1;
    */

    // Statically define an aray using integer
   string strings[] = {"battleship", "boot", "cannon", "iron", "thimble", "top hat"};

   string s = get_string("String: ");
   for (int i = 0; i < 6; i++)
   {
        if(strcmp(strings[i], s) == 0)
        {
            printf("Found!\n");
            return 0;
        }
   }
   printf("Not Found!\n");
   return 1;


}