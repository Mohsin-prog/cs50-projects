#include <cs50.h>
#include <stdio.h>
#include <string.h>

//Factorial
int fact(int n)
{
    //base case
    if (n==1)
    {
        return 1;
    }

    //recursive case
    else
    {
        return n * fact(n-1);
    }
}


//Iteration
int fact2(int n)
{
    int product = 1; 
    while(n > 0)
    {
        product *= n;
        n--;
    }
    return product;
}