#include <cs50.h>
#include <stdio.h>

int factorial(int number);

int main(void)
{
    //Prompt the user for a number
    int n = get_int("Type a Number: ");
    printf("%i\n", factorial(n));
}

int factorial(int number)
{
    if (number == 1)
    {
        return 1;
    }
    //Recursice // recursion method
    return number * factorial(number - 1);

    //loop method
    int solution = number;
    for (int i = number; i > 0; i--)
    {
        solution = solution * 1;
    }
}
