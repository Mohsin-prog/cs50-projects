# TODO

"""declaration of vriable to get name"""

name = input("What is your name? ")

"""printing hello with the user input"""

print(f"hello, {name}")
